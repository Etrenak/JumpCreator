package fr.etrenak.jumpcreator.commands;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Chicken;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import fr.etrenak.jumpcreator.JumpCreator;
import fr.etrenak.jumpcreator.Util;
import fr.etrenak.jumpcreator.config.JumpLevel;

public class JumpCreate implements CommandExecutor
{
	private List<Location> previousLocs;

	public JumpCreate()
	{
		previousLocs = new LinkedList<>();
	}

	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
	{
		if(!(sender instanceof Player))
		{
			sender.sendMessage("§cPlayer only");
			return true;
		}

		if(args.length < 2 || !args[0].matches("\\d+") || JumpCreator.getInstance().getLevelsManager().getJumpLevel(args[1].toLowerCase()) == null)
		{
			sender.sendMessage("§c/JumpCreate <nombre de blocs> [" + String.join("|", JumpCreator.getInstance().getLevelsManager().getLevels()) + "]");
			return true;
		}

		JumpLevel level = JumpCreator.getInstance().getLevelsManager().getJumpLevel(args[1]);

		Player p = (Player) sender;
		Location current = p.getLocation().clone();
		Location prevLoc = current.clone();
		double angle = 0;
		double length = 0;
		Random rdm = new Random();

		boolean jumpable;
		Material rdmMat = level.getRandomMaterial(rdm);
		int deltaY = 1;

		previousLocs.clear();

		current.getBlock().setType(rdmMat);

		prevLoc = current.clone();
		previousLocs.add(prevLoc);

		for(int jumpLocIndex = 0; jumpLocIndex < Integer.parseInt(args[0]); jumpLocIndex++)
		{
			deltaY = 1;
			rdmMat = level.getRandomMaterial(rdm);
			length = rdm.nextInt(level.getMaxGap() + 1 - level.getMinGap()) + level.getMinGap();

			if(rdmMat == Material.FENCE)
			{
				deltaY = 0;
				if(length > 1)
					length -= 1;
			}
			jumpable = false;

			while(!jumpable)
			{
				double lastAngle = angle;

				boolean changeDirection = rdm.nextInt(100) > level.getChangeDirectionChance();
				Chicken poulet = (Chicken) current.getWorld().spawnEntity(current.clone().add(0.5, 1, 0.5), EntityType.CHICKEN);
				poulet.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 10000, 100000));
				poulet.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 10000, 100000));
				poulet.setCustomNameVisible(true);
				poulet.setCustomName(changeDirection + "");
				do
				{
					angle = Math.toRadians(rdm.nextInt(361));
				}while(changeDirection == Math.abs((angle - (lastAngle + Math.PI)) % Math.PI) < Math.PI / 2);

				current.setX(Math.round(length * Math.cos(angle)) + prevLoc.getBlockX());
				current.setZ(Math.round(length * Math.sin(angle)) + prevLoc.getBlockZ());
				current.setY(prevLoc.getY() + deltaY);

				if(previousLocs.size() > 1)
				{
					for(int prevLocsIndex = 1; prevLocsIndex <= Math.min(previousLocs.size() - 1, 3); prevLocsIndex++)
					{
						if(Util.getDistanceToSegment(previousLocs.get(previousLocs.size() - prevLocsIndex).getBlockX(), previousLocs.get(previousLocs.size() - prevLocsIndex).getBlockZ(), previousLocs.get(previousLocs.size() - prevLocsIndex - 1).getBlockX(), previousLocs.get(previousLocs.size() - prevLocsIndex - 1).getBlockZ(), current.getBlockX(), current.getBlockZ()) < Math.min(length, level.getMinDistanceSecondJumpToLineOfJump()))
						{
							jumpable = false;
							break;
						}
						else
						{
							jumpable = true;
						}

					}
				}
				else
				{
					jumpable = true;
				}

			}

			current.getBlock().setType(rdmMat);

			prevLoc = current.clone();
			previousLocs.add(prevLoc);
		}

		return true;
	}
}
