package fr.etrenak.jumpcreator.config;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

public class JumpLevel
{
	private String name;

	private int maxGap;
	private int minGap;
	private int minDistanceSecondJumpToLineOfJump;

	private List<Material> blocks;

	private int changeDirectionChance;
	private int blockOverHeadChance;

	private Material defaultBlock;

	public JumpLevel(String name, ConfigurationSection config)
	{
		this.name = name;
		maxGap = config.getInt("MaxGap");
		minGap = config.getInt("MinGap");
		minDistanceSecondJumpToLineOfJump = config.getInt("Min2ndJumpDistance");
		changeDirectionChance = config.getInt("ChangeDirectionChance");
		blockOverHeadChance = config.getInt("BlockOverHeadChance");

		defaultBlock = Material.valueOf(config.getString("DefaultBlock"));

		blocks = new ArrayList<Material>();
		for(String key : config.getConfigurationSection("BlocksChances").getKeys(false))
			for(int i = 0; i < config.getInt("BlocksChances." + key); i++)
				blocks.add(Material.valueOf(key));
		
		for(int i = blocks.size() -1;i<100;i++)
			blocks.add(defaultBlock);
	}

	public Material getRandomMaterial(Random rdm)
	{
		return blocks.get(rdm.nextInt(100));
	}

	public Material getDefaultBlock()
	{
		return defaultBlock;
	}

	public int getBlockOverHeadChance()
	{
		return blockOverHeadChance;
	}

	public String getName()
	{
		return name;
	}

	public int getMaxGap()
	{
		return maxGap;
	}

	public int getMinGap()
	{
		return minGap;
	}

	public int getMinDistanceSecondJumpToLineOfJump()
	{
		return minDistanceSecondJumpToLineOfJump;
	}

	public int getChangeDirectionChance()
	{
		return changeDirectionChance;
	}

}
